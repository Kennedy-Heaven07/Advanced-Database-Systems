class MinitermFragmentGenerator:
    def __init__(self, predicates):
        self.predicates = predicates

    def generate_horizontal_miniterm_fragments(self):
        miniterms = []
        for predicate in self.predicates:
            miniterm = {}
            for key, value in predicate.items():
                if isinstance(value, list):
                    for item in value:
                        miniterm[key] = item
                        miniterms.append(miniterm.copy())
                else:
                    miniterm[key] = value
            if miniterm not in miniterms:
                miniterms.append(miniterm)
        return miniterms

# Example usage a predicates list with Dictionary
predicates = [
    {'Brand': ['Apple', 'Lenovo'], 'color': 'silver'},
    {'Brand': 'hp', 'color': 'Black'},
    {'Brand': ['ROG', 'Omen'], 'type': 'gaming'}
]

fragment_generator = MinitermFragmentGenerator(predicates)
fragments = fragment_generator.generate_horizontal_miniterm_fragments()
print(fragments)
