CREATE OR REPLACE TYPE miniterm AS OBJECT (
    attribute VARCHAR2(100),
    value VARCHAR2(100)
);

CREATE OR REPLACE TYPE miniterm_list AS TABLE OF miniterm;

CREATE OR REPLACE FUNCTION generate_horizontal_miniterm_fragments(
    predicates IN miniterm_list
) RETURN miniterm_list PIPELINED IS
    miniterm_rec miniterm;
BEGIN
    FOR i IN 1..predicates.COUNT LOOP
        IF predicates(i).value IS NULL THEN
            PIPE ROW (miniterm(predicates(i).attribute, NULL));
        ELSIF predicates(i).value IS NOT NULL THEN
            PIPE ROW (miniterm(predicates(i).attribute, predicates(i).value));
        END IF;
    END LOOP;
    RETURN;
END;

